var krms_config ={						
	'ApiUrl':"https://restomulti.herokuapp.com/mobileappv2/api",    
	'AppTitle':"Bargain Grub",
	'ApiKey' : 'ab026d43d72373ea59773bc8812fdd9f2',	
 	'LicenseKey': '4e3a60b390a77c3b3d2bba47d7fb8b2b',
	'debug': false
};